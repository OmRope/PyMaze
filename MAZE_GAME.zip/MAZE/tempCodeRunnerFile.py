label = tk.Label(root, text="Hello, World!")
        label.grid(row=0, columnspan=2, pady=10, sticky="n")
